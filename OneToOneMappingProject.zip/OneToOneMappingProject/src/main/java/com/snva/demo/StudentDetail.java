package com.snva.demo;

import jakarta.persistence.*;

@Entity
@Table(name = "studentdetail")
public class StudentDetail {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @Column(name = "college")
    private String college;

    @Column(name = "no_of_problems_solved")
    private int noOfProblemsSolved;

    @OneToOne(cascade = CascadeType.ALL, mappedBy = "studentDetail")
    private Student student;

    public StudentDetail()
    {

    }
    public StudentDetail(String college, int noOfProblemsSolved)
    {
        this.college = college;
        this.noOfProblemsSolved = noOfProblemsSolved;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    public int getNoOfProblemsSolved() {
        return noOfProblemsSolved;
    }

    public void setNoOfProblemsSolved(int noOfProblemsSolved) {
        this.noOfProblemsSolved = noOfProblemsSolved;
    }

    public String getCollege() {
        return college;
    }

    public void setCollege(String college) {
        this.college = college;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
