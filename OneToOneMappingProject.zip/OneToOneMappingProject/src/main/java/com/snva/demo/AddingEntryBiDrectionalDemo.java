package com.snva.demo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class AddingEntryBiDrectionalDemo {
    public static void main(String[] args) {
        SessionFactory factory = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Student.class).addAnnotatedClass(StudentDetail.class).buildSessionFactory();

        try (Session session = factory.getCurrentSession())
        {
            Student s1 = new Student("John", "Smith", "john@gmail.com");
            Student s2 = new Student("Jane", "Williams", "jane@gmail.com");
            Student s3 = new Student("Gregory", "Daniels", "greg@gmail.com");
            Student s4 = new Student("Chester", "Wood", "wood@gmail.com");

            StudentDetail sd1 = new StudentDetail("SNVA", 20);

            StudentDetail sd2 = new StudentDetail("Harvard", 40);
            StudentDetail sd4 = new StudentDetail("SNVA", 65);

            s1.setStudentDetail(sd1);
            sd1.setStudent(s1);
            s2.setStudentDetail(sd2);
            sd2.setStudent(s2);
            s4.setStudentDetail(sd4);
            sd4.setStudent(s4);
            session.beginTransaction();
            session.persist(s1);
            session.persist(sd2);
            session.persist(s3);
            session.persist(s4);
            System.out.println("Transaction Completed");

            s4.setEmail("chester@gmail.com");
            session.merge(sd4);
            session.getTransaction().commit();


        } catch(Exception e)
        {
            e.printStackTrace();
        }
    }
}
